# damianvink.nl

Personal site of Damian Vink — Project Engineer werktuigbouwkunde & machinebouw.

## Site structure (URL map)

```
/                              Home
/over-mij                      About
/werk                          Work
/contact                       Contact
/kennis/                       Knowledge hub
  /kennis/engineering/         Engineering hub
    /tools/                    Tools & reference (subpages coming soon)
    /artikelen/                Article index
      /s235jr-vs-s235jrg2      Material article
      /s235jr-vs-s235jrh       Material article
    /ontwikkelingen/           Developments (placeholder)
  /gezonde-voeding/            Nutrition hub
    /wat-is-gezonde-voeding
  /hardlopen/
    /marathon-trainingsschema-beginners
    /marathon-voeding-en-vocht
```

Root-level files like `engineering.html` and `s235jr-vs-s235jrg2.html` are **redirects** to the new paths so old links keep working.

## Features

- Dark mode by default + light mode + system preference + toggle
- Breadcrumbs on nested pages
- Clear knowledge hierarchy
- Material articles reachable via Engineering → Artikelen
- Missing tool pages marked “Binnenkort” (no dead links)

## Deploy

Static GitHub Pages site (`CNAME` → damianvink.nl).

```bash
git add .
git commit -m "Restructure site: nested knowledge map, fix articles, professional dark UI"
git push origin main
```

## Local preview

```bash
python3 -m http.server 8000
```

Open http://localhost:8000 — use paths like `/kennis/engineering/artikelen/s235jr-vs-s235jrg2` (with or without `.html` depending on server).
